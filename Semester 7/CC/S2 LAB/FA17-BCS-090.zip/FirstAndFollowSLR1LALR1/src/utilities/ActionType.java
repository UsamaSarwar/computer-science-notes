package utilities;
/**
 *
 * @author Usama Sarwar
 */
public enum ActionType {
    ACCEPT,SHIFT,REDUCE
}

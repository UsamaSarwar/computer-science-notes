package utilities;

public enum ActionType {
    ACCEPT,SHIFT,REDUCE
}

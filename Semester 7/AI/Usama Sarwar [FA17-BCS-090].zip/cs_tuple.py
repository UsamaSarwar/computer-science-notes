values = input("Comma Seprated Numbers: ")
list = values.split(",") # convert to list
print('List : ',list)
tuple = tuple(list)  # convert to tuple
print('Tuple : ',tuple)
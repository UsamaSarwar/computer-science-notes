from _collections import defaultdict

class Graph:
    def _init_(self,vertices):
        self.ver=vertices
        self.graphlist= defaultdict(list)

    def EdgeAddition(self,u ,v):
        self.graphlist[u].append(v)


    def DLS(self,s,t,d):
        if  s==t: return True

        if d<=0: return False

        for i in self.graphlist[s]:
            if(self.DLS(i,t,d-1)):
                return True
        return False



vertices=int(input("Enter Total vertices: "))
g= Graph(vertices)

for i in range(vertices):
    x=int(input("Enter First: "))
    y=int(input("Enter Second: "))
    g.EdgeAddition(x,y)


s = int(input("Enter Source: "))
t = int(input("Enter Target: "))
d = int(input("Enter Depth: "))

print()


if g.DLS(s,t,d)==True:
    print("Target is  reachable from source")
else:
    print("Target is not reachable from source")

print()